package com.example.kampusmate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kampusmate.models.User;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvNim, tvEmail, tvProdi;
    private Button btnEdit, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        initViews();
        loadUserData();
        setupListeners();
    }

    private void initViews() {
        tvName = findViewById(R.id.tvName);
        tvNim = findViewById(R.id.tvNim);
        tvEmail = findViewById(R.id.tvEmail);
        tvProdi = findViewById(R.id.tvProdi);
        btnEdit = findViewById(R.id.btnEdit);
        btnLogout = findViewById(R.id.btnLogout);
    }

    private void loadUserData() {
        // Load dari SharedPreferences
        android.content.SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);

        String name = prefs.getString("name", "Fasyal Muhammad");
        String nim = prefs.getString("nim", "31241000123");
        String email = prefs.getString("email", "FasyalMuhammad62@gmail.com");
        String prodi = prefs.getString("prodi", "Teknik Informatika");

        tvName.setText(name);
        tvNim.setText(nim);
        tvEmail.setText(email);
        tvProdi.setText(prodi);
    }

    private void setupListeners() {
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(ProfileActivity.this, EditProfileActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            // Clear session/logout
            android.content.SharedPreferences.Editor editor =
                    getSharedPreferences("user_session", MODE_PRIVATE).edit();
            editor.clear();
            editor.apply();

            Intent intent = new Intent(ProfileActivity.this, SplashActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData(); // Refresh data setelah edit
    }
}