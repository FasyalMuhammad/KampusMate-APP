package com.example.kampusmate;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddScheduleActivity extends AppCompatActivity {

    private EditText etCourseName, etTime, etRoom, etLecturer;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etCourseName = findViewById(R.id.etCourseName);
        etTime = findViewById(R.id.etTime);
        etRoom = findViewById(R.id.etRoom);
        etLecturer = findViewById(R.id.etLecturer);
        btnSave = findViewById(R.id.btnSave);
    }

    private void setupListeners() {
        btnSave.setOnClickListener(v -> {
            String courseName = etCourseName.getText().toString().trim();
            String time = etTime.getText().toString().trim();
            String room = etRoom.getText().toString().trim();
            String lecturer = etLecturer.getText().toString().trim();

            if (courseName.isEmpty() || time.isEmpty() || room.isEmpty() || lecturer.isEmpty()) {
                Toast.makeText(this, "Harap isi semua field", Toast.LENGTH_SHORT).show();
                return;
            }

            // Simpan ke database/shared preferences
            saveSchedule(courseName, time, room, lecturer);

            Toast.makeText(this, "Jadwal berhasil disimpan", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void saveSchedule(String courseName, String time, String room, String lecturer) {
        // Implementasi penyimpanan ke SharedPreferences atau database
        // Contoh menggunakan SharedPreferences
        android.content.SharedPreferences prefs = getSharedPreferences("schedules", MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = prefs.edit();

        // Generate ID unik
        String id = String.valueOf(System.currentTimeMillis());

        com.google.gson.Gson gson = new com.google.gson.Gson();
        com.example.kampusmate.models.Schedule schedule =
                new com.example.kampusmate.models.Schedule(courseName, time, room, lecturer, "Kamis");
        schedule.setId(id);

        String scheduleJson = gson.toJson(schedule);
        editor.putString(id, scheduleJson);
        editor.apply();
    }
}