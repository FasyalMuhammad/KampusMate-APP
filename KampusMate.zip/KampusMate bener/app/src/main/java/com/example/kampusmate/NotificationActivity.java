package com.example.kampusmate;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kampusmate.models.NotificationPref;

public class NotificationActivity extends AppCompatActivity {

    private Switch switchSchedule, switchQuiz, switchTask, switchReminder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        initViews();
        loadNotificationPrefs();
        setupListeners();
    }

    private void initViews() {
        switchSchedule = findViewById(R.id.switchSchedule);
        switchQuiz = findViewById(R.id.switchQuiz);
        switchTask = findViewById(R.id.switchTask);
        switchReminder = findViewById(R.id.switchReminder);
    }

    private void loadNotificationPrefs() {
        android.content.SharedPreferences prefs = getSharedPreferences("notification_prefs", MODE_PRIVATE);

        NotificationPref pref = new NotificationPref(
                prefs.getBoolean("schedule_today", true),
                prefs.getBoolean("quiz", true),
                prefs.getBoolean("task", true),
                prefs.getBoolean("reminder", true)
        );

        switchSchedule.setChecked(pref.isScheduleToday());
        switchQuiz.setChecked(pref.isQuiz());
        switchTask.setChecked(pref.isTask());
        switchReminder.setChecked(pref.isReminder());
    }

    private void setupListeners() {
        CompoundButton.OnCheckedChangeListener listener = (buttonView, isChecked) -> {
            saveNotificationPrefs();
        };

        switchSchedule.setOnCheckedChangeListener(listener);
        switchQuiz.setOnCheckedChangeListener(listener);
        switchTask.setOnCheckedChangeListener(listener);
        switchReminder.setOnCheckedChangeListener(listener);
    }

    private void saveNotificationPrefs() {
        NotificationPref pref = new NotificationPref(
                switchSchedule.isChecked(),
                switchQuiz.isChecked(),
                switchTask.isChecked(),
                switchReminder.isChecked()
        );

        android.content.SharedPreferences prefs = getSharedPreferences("notification_prefs", MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = prefs.edit();

        editor.putBoolean("schedule_today", pref.isScheduleToday());
        editor.putBoolean("quiz", pref.isQuiz());
        editor.putBoolean("task", pref.isTask());
        editor.putBoolean("reminder", pref.isReminder());

        editor.apply();
    }
}