package com.example.kampusmate.models;

public class NotificationPref {
    private boolean scheduleToday;
    private boolean quiz;
    private boolean task;
    private boolean reminder;

    public NotificationPref(boolean scheduleToday, boolean quiz, boolean task, boolean reminder) {
        this.scheduleToday = scheduleToday;
        this.quiz = quiz;
        this.task = task;
        this.reminder = reminder;
    }

    // Getters and Setters
    public boolean isScheduleToday() { return scheduleToday; }
    public void setScheduleToday(boolean scheduleToday) { this.scheduleToday = scheduleToday; }

    public boolean isQuiz() { return quiz; }
    public void setQuiz(boolean quiz) { this.quiz = quiz; }

    public boolean isTask() { return task; }
    public void setTask(boolean task) { this.task = task; }

    public boolean isReminder() { return reminder; }
    public void setReminder(boolean reminder) { this.reminder = reminder; }
}