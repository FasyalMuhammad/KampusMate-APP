package com.example.kampusmate;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditProfileActivity extends AppCompatActivity {

    private EditText etName, etNim, etEmail, etProdi;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);  // Pastikan nama layout ini sesuai

        initViews();
        loadCurrentData();
        setupListeners();
    }

    private void initViews() {
        etName = findViewById(R.id.etName);
        etNim = findViewById(R.id.etNim);
        etEmail = findViewById(R.id.etEmail);
        etProdi = findViewById(R.id.etProdi);
        btnSave = findViewById(R.id.btnSave);
    }

    private void loadCurrentData() {
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);

        etName.setText(prefs.getString("name", "Fasyal Muhammad"));
        etNim.setText(prefs.getString("nim", "31241000123"));
        etEmail.setText(prefs.getString("email", "FasyalMuhammad62@gmail.com"));
        etProdi.setText(prefs.getString("prodi", "Teknik Informatika"));
    }

    private void setupListeners() {
        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String nim = etNim.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String prodi = etProdi.getText().toString().trim();

            if (name.isEmpty() || nim.isEmpty() || email.isEmpty() || prodi.isEmpty()) {
                Toast.makeText(this, "Harap isi semua field", Toast.LENGTH_SHORT).show();
                return;
            }

            saveProfile(name, nim, email, prodi);
            Toast.makeText(this, "Profil berhasil diperbarui", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void saveProfile(String name, String nim, String email, String prodi) {
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("name", name);
        editor.putString("nim", nim);
        editor.putString("email", email);
        editor.putString("prodi", prodi);

        editor.apply();
    }
}