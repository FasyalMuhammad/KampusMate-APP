package com.example.kampusmate;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.kampusmate.models.Schedule;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScheduleListActivity extends AppCompatActivity {

    private Button btnMonday, btnTuesday, btnWednesday, btnThursday;
    private RecyclerView rvSchedules;
    private TextView tvSelectedDay;

    private Map<String, List<Schedule>> scheduleMap;
    private String selectedDay = "Senin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_list);

        initViews();
        loadSchedules();
        setupDaySelection();
        showSchedulesForDay(selectedDay);
    }

    private void initViews() {
        btnMonday = findViewById(R.id.btnMonday);
        btnTuesday = findViewById(R.id.btnTuesday);
        btnWednesday = findViewById(R.id.btnWednesday);
        btnThursday = findViewById(R.id.btnThursday);
        rvSchedules = findViewById(R.id.rvSchedules);
        tvSelectedDay = findViewById(R.id.tvSelectedDay);
    }

    private void loadSchedules() {
        scheduleMap = new HashMap<>();

        // Data dummy untuk Senin
        List<Schedule> senin = new ArrayList<>();
        senin.add(new Schedule("Pemrograman", "09:00-11:00", "Ruang 12", "Dosen A", "Senin"));
        senin.add(new Schedule("Statistika", "12:30-14:30", "Ruang 12", "Dosen B", "Senin"));
        scheduleMap.put("Senin", senin);

        // Data dummy untuk Selasa
        List<Schedule> selasa = new ArrayList<>();
        selasa.add(new Schedule("Agama", "15:30-17:00", "Ruang 12", "Dosen C", "Selasa"));
        scheduleMap.put("Selasa", selasa);

        // Data dummy untuk Rabu
        List<Schedule> rabu = new ArrayList<>();
        rabu.add(new Schedule("Matematika", "08:00-10:00", "Ruang 10", "Dosen D", "Rabu"));
        scheduleMap.put("Rabu", rabu);

        // Data dummy untuk Kamis
        List<Schedule> kamis = new ArrayList<>();
        kamis.add(new Schedule("Pemrograman", "09:00-11:00", "Ruang 12", "Dosen A", "Kamis"));
        kamis.add(new Schedule("Statistika", "12:30-14:30", "Ruang 12", "Dosen B", "Kamis"));
        kamis.add(new Schedule("Agama", "15:30-17:00", "Ruang 12", "Dosen C", "Kamis"));
        scheduleMap.put("Kamis", kamis);
    }

    private void setupDaySelection() {
        btnMonday.setOnClickListener(v -> showSchedulesForDay("Senin"));
        btnTuesday.setOnClickListener(v -> showSchedulesForDay("Selasa"));
        btnWednesday.setOnClickListener(v -> showSchedulesForDay("Rabu"));
        btnThursday.setOnClickListener(v -> showSchedulesForDay("Kamis"));
    }

    private void showSchedulesForDay(String day) {
        selectedDay = day;
        tvSelectedDay.setText("Jadwal " + day);

        List<Schedule> schedules = scheduleMap.getOrDefault(day, new ArrayList<>());

        ScheduleAdapter adapter = new ScheduleAdapter(schedules);
        rvSchedules.setLayoutManager(new LinearLayoutManager(this));
        rvSchedules.setAdapter(adapter);
    }

    private class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {
        private List<Schedule> schedules;

        public ScheduleAdapter(List<Schedule> schedules) {
            this.schedules = schedules;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_schedule, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Schedule schedule = schedules.get(position);
            holder.tvCourseName.setText(schedule.getCourseName());
            holder.tvTime.setText(schedule.getTime());
            holder.tvRoom.setText(schedule.getRoom());
        }

        @Override
        public int getItemCount() {
            return schedules.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvCourseName, tvTime, tvRoom;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvCourseName = itemView.findViewById(R.id.tvCourseName);
                tvTime = itemView.findViewById(R.id.tvTime);
                tvRoom = itemView.findViewById(R.id.tvRoom);
            }
        }
    }
}