package com.example.kampusmate;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.kampusmate.models.Schedule;
import com.example.kampusmate.models.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvGreeting;
    private Button btnAddSchedule;
    private RecyclerView rvTodaySchedule;

    // Data dummy
    private User currentUser;
    private List<Schedule> todaySchedules;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        initViews();
        loadUserData();
        setupTodaySchedule();
        setupListeners();
    }

    private void initViews() {
        tvGreeting = findViewById(R.id.tvGreeting);
        btnAddSchedule = findViewById(R.id.btnAddSchedule);
        rvTodaySchedule = findViewById(R.id.rvTodaySchedule);
    }

    private void loadUserData() {
        // Simulasi data user
        currentUser = new User(
                "Fasyal Muhammad",
                "31241000123",
                "FasyalMuhammad62@gmail.com",
                "Teknik Informatika"
        );

        // Tampilkan sapaan
        String[] days = {"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
        String[] months = {"Januari", "Februari", "Maret", "April", "Mei", "Juni",
                "Juli", "Agustus", "September", "Oktober", "November", "Desember"};

        Calendar calendar = Calendar.getInstance();
        String dayName = days[calendar.get(Calendar.DAY_OF_WEEK) - 1];
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        String month = months[calendar.get(Calendar.MONTH)];
        int year = calendar.get(Calendar.YEAR);

        String greeting = "Halo, " + currentUser.getName() + "\n" +
                dayName + ", " + day + " " + month + " " + year;
        tvGreeting.setText(greeting);
    }

    private void setupTodaySchedule() {
        // Data dummy jadwal hari ini
        todaySchedules = new ArrayList<>();
        todaySchedules.add(new Schedule("Pemrograman", "09:00-11:00", "Ruang 12", "Dosen A", "Kamis"));
        todaySchedules.add(new Schedule("Statistika", "12:30-14:30", "Ruang 12", "Dosen B", "Kamis"));

        // Setup RecyclerView
        ScheduleAdapter adapter = new ScheduleAdapter(todaySchedules);
        rvTodaySchedule.setLayoutManager(new LinearLayoutManager(this));
        rvTodaySchedule.setAdapter(adapter);
    }

    private void setupListeners() {
        btnAddSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddScheduleActivity.class);
            startActivity(intent);
        });

        // Bottom Navigation
        findViewById(R.id.nav_home).setOnClickListener(v -> {
            // Already on home
        });

        findViewById(R.id.nav_schedule).setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ScheduleListActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.nav_notif).setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, NotificationActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.nav_profile).setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ProfileActivity.class);
            startActivity(intent);
        });
    }

    // Inner class untuk adapter
    private class ScheduleAdapter extends RecyclerView.Adapter<ScheduleAdapter.ViewHolder> {
        private List<Schedule> schedules;

        public ScheduleAdapter(List<Schedule> schedules) {
            this.schedules = schedules;
        }

        @Override
        public ViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_schedule, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Schedule schedule = schedules.get(position);
            holder.tvCourseName.setText(schedule.getCourseName());
            holder.tvTime.setText(schedule.getTime());
            holder.tvRoom.setText(schedule.getRoom());
        }

        @Override
        public int getItemCount() {
            return schedules.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvCourseName, tvTime, tvRoom;

            ViewHolder(android.view.View itemView) {
                super(itemView);
                tvCourseName = itemView.findViewById(R.id.tvCourseName);
                tvTime = itemView.findViewById(R.id.tvTime);
                tvRoom = itemView.findViewById(R.id.tvRoom);
            }
        }
    }
}