package com.example.kampusmate.models;

public class Schedule {
    private String id;
    private String courseName;
    private String time;
    private String room;
    private String lecturer;
    private String day;

    public Schedule(String courseName, String time, String room, String lecturer, String day) {
        this.courseName = courseName;
        this.time = time;
        this.room = room;
        this.lecturer = lecturer;
        this.day = day;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public String getRoom() { return room; }
    public void setRoom(String room) { this.room = room; }

    public String getLecturer() { return lecturer; }
    public void setLecturer(String lecturer) { this.lecturer = lecturer; }

    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }
}