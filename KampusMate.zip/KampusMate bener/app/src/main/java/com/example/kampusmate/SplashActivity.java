package com.example.kampusmate;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    private TextView tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tvWelcome = findViewById(R.id.tvWelcome);

        // Deteksi bahasa berdasarkan locale
        String currentLanguage = Locale.getDefault().getLanguage();
        String country = Locale.getDefault().getCountry();

        setWelcomeMessage(currentLanguage, country);

        // Splash screen selama 2.5 detik
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, DashboardActivity.class);
            startActivity(intent);
            finish();
        }, 2500);
    }

    private void setWelcomeMessage(String language, String country) {
        String welcomeMessage = "";
        String flagEmoji = "";

        // Cek bahasa dan negara
        if ("id".equals(language) || "ID".equals(country)) {
            flagEmoji = "🇮🇩";
            welcomeMessage = "Halo, selamat datang di aplikasi KAMPUSmate";
        } else if ("en".equals(language) || "US".equals(country) || "GB".equals(country)) {
            flagEmoji = "🇬🇧";
            welcomeMessage = "Hello, welcome to the KAMPUSmate app";
        } else if ("ja".equals(language) || "JP".equals(country)) {
            flagEmoji = "🇯🇵";
            welcomeMessage = "こんにちは、KAMPUSmateアプリへようこそ";
        } else if ("ko".equals(language) || "KR".equals(country)) {
            flagEmoji = "🇰🇷";
            welcomeMessage = "안녕하세요, KAMPUSmate 앱에 오신 것을 환영합니다";
        } else {
            // Default ke Indonesia
            flagEmoji = "🇮🇩";
            welcomeMessage = "Halo, selamat datang di aplikasi KAMPUSmate";
        }

        tvWelcome.setText(flagEmoji + " " + welcomeMessage);
    }
}