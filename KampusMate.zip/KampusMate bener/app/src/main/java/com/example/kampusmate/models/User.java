package com.example.kampusmate.models;

public class User {
    private String name;
    private String nim;
    private String email;
    private String prodi;

    public User(String name, String nim, String email, String prodi) {
        this.name = name;
        this.nim = nim;
        this.email = email;
        this.prodi = prodi;
    }

    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getNim() { return nim; }
    public void setNim(String nim) { this.nim = nim; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getProdi() { return prodi; }
    public void setProdi(String prodi) { this.prodi = prodi; }
}